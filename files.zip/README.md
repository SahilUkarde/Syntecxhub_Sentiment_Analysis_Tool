# Sentiment Analysis Tool

A small end-to-end **sentiment analysis** project: load labeled text data
(tweets/reviews), clean and tokenize it, convert it into numeric features
(TF-IDF), train a classifier (Naive Bayes & Logistic Regression), evaluate it
(accuracy & F1), and use it from a simple command-line interface (CLI) to
classify new text as **positive**, **negative**, or **neutral**.

## Project Structure

```
sentiment-analysis-tool/
├── data/
│   ├── generate_data.py     # generates the sample dataset (optional)
│   └── sentiment_data.csv   # labeled dataset (text, label)
├── model/                    # created after training — saved model artifacts
│   ├── sentiment_model.joblib
│   ├── vectorizer.joblib
│   ├── label_encoder.joblib
│   └── model_info.txt
├── src/
│   ├── preprocess.py         # text cleaning / tokenization
│   ├── train.py               # training + evaluation pipeline
│   └── predict.py             # CLI for predicting sentiment
├── requirements.txt
└── README.md
```

## 1. Setup

```bash
git clone <your-repo-url>
cd sentiment-analysis-tool

python3 -m venv venv
source venv/bin/activate      # on Windows: venv\Scripts\activate

pip install -r requirements.txt
```

## 2. Dataset

A ready-to-use sample dataset is included at `data/sentiment_data.csv` with
two columns:

| column | description                                |
|--------|---------------------------------------------|
| `text` | the raw tweet / review text                  |
| `label`| sentiment label: `positive`, `negative`, or `neutral` |

It was generated with `data/generate_data.py` (~900 example sentences) so the
pipeline works out of the box. You can regenerate it with:

```bash
python data/generate_data.py
```

### Using your own / real-world data

To use a real dataset (e.g. Sentiment140, IMDB Reviews, Amazon Product
Reviews, or any Kaggle tweet/review dataset):

1. Download the dataset (CSV format).
2. Make sure it has (or rename its columns to) `text` and `label`.
3. If labels are numeric (e.g. `0`/`1`/`4` for negative/neutral/positive in
   Sentiment140), map them to `negative` / `neutral` / `positive` strings
   first — for example:

   ```python
   import pandas as pd
   df = pd.read_csv("your_dataset.csv")
   mapping = {0: "negative", 2: "neutral", 4: "positive"}
   df["label"] = df["label"].map(mapping)
   df[["text", "label"]].to_csv("data/sentiment_data.csv", index=False)
   ```

4. Point `train.py` at it with `--data path/to/your_dataset.csv`.

## 3. Train the model

```bash
python src/train.py
```

This will:
- Load `data/sentiment_data.csv`
- Clean & tokenize the text (`src/preprocess.py`)
- Convert text to TF-IDF features
- Train **Multinomial Naive Bayes** and **Logistic Regression**
- Print **accuracy** and **weighted F1-score** plus a full classification
  report for both models
- Save the best-performing model, the TF-IDF vectorizer, and the label
  encoder to `model/`

To use your own dataset:

```bash
python src/train.py --data path/to/your_dataset.csv
```

## 4. Predict sentiment via the CLI

Single text:

```bash
python src/predict.py --text "I absolutely love this product!"
```

```
Text     : I absolutely love this product!
Sentiment: POSITIVE 🙂
```

Show confidence scores per class:

```bash
python src/predict.py --text "This is the worst app I've ever used" --show-probs
```

```
Text     : This is the worst app I've ever used
Sentiment: NEGATIVE 🙁
Confidence:
  negative  : 64.30%
  positive  : 22.78%
  neutral   : 12.93%
```

Interactive mode (keeps prompting for input):

```bash
python src/predict.py
```

```
=== Sentiment Analysis CLI ===
Type a sentence and press Enter to see its predicted sentiment.
Type 'exit' or 'quit' to stop.

> The delivery was super fast and the staff were friendly!
Text     : The delivery was super fast and the staff were friendly!
Sentiment: POSITIVE 🙂

> exit
Goodbye!
```

## How it works

1. **Preprocessing** (`src/preprocess.py`): lowercases text, strips URLs,
   @mentions, hashtag symbols, punctuation, and numbers, then removes common
   English stopwords and very short tokens.
2. **Feature extraction**: `TfidfVectorizer` (unigrams + bigrams, max 5,000
   features) converts cleaned text into numeric vectors.
3. **Modeling**: both `MultinomialNB` and `LogisticRegression` are trained on
   an 80/20 train/test split. The model with the higher weighted F1-score on
   the test set is saved for use by the CLI.
4. **Evaluation**: accuracy, precision, recall, and F1-score (per class and
   weighted average) are printed for both models so you can compare them.

## Extending the project

- Swap in a real dataset for better generalization on your domain.
- Add more sentiment classes (e.g. "very positive" / "very negative").
- Try other vectorizers (`CountVectorizer`) or models (SVM, Random Forest).
- Wrap `predict.py`'s `predict_sentiment()` function in a Flask/FastAPI app
  to expose it as a web API.

## License

Feel free to use, modify, and share this project.
